    ESX = exports["es_extended"]:getSharedObject()

    local isRobbing = false
    local currentLootIndex = 1
    local lastRobberyTime = 0
    local lootedCPs = {}
    local config = Config
    local blips = {}  
    function CreateWeaponBlip(coords)
        local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
        SetBlipSprite(blip, 110)  
        SetBlipColour(blip, 1)  
        SetBlipScale(blip, 1.0)  
        SetBlipAsShortRange(blip, false) 
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Rablás Helyszín")  
        EndTextCommandSetBlipName(blip)
    end
    local coords = vector3(3091.39, -4722.86, 27.28)  
    CreateWeaponBlip(coords)
    local isRobberyActive = false
    local spawnedZombies = {}
    function CreateLootBlips()
        for index, lootCP in ipairs(Config.LootCPs) do
            local blip = AddBlipForCoord(lootCP.x, lootCP.y, lootCP.z)
            SetBlipSprite(blip, 161)  
            SetBlipColour(blip, 2)    
            SetBlipScale(blip, 0.8)   
            SetBlipAsShortRange(blip, true)  
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Loot Point")  
            EndTextCommandSetBlipName(blip)
            blips[index] = blip
        end
    end
RegisterNetEvent('startRobberyClient')
AddEventHandler('startRobberyClient', function()
    local currentTime = GetGameTimer() / 1000  
    if currentTime - lastRobberyTime < Config.RobberyCooldown then
        local remainingTime = Config.RobberyCooldown - (currentTime - lastRobberyTime)
        TriggerEvent('sendNotification', "Hiba", "A rablás újraindításához még " .. math.ceil(remainingTime) .. " másodperc várakozás szükséges!", 5000, 'error')
        return  
    end
    lastRobberyTime = currentTime  
    isRobberyActive = true
    spawnedZombies = {}
    lootedCPs = {}  
    for index, blip in ipairs(blips) do
        RemoveBlip(blip)
    end
    blips = {}  
    CreateLootBlips()  
    StartZombieWaves()  
    TriggerServerEvent('startRobberyServer')
end)
    RegisterNetEvent('stopRobberyClient')
    AddEventHandler('stopRobberyClient', function()
        isRobberyActive = false
        for _, zombie in ipairs(spawnedZombies) do
            if DoesEntityExist(zombie) then
                DeleteEntity(zombie)
            end
        end
        spawnedZombies = {}
        for index, blip in ipairs(blips) do
            RemoveBlip(blip)
        end
        blips = {}

        sendNotification("Rablás vége", "A rablás befejeződött!", 5000, 'error')
    end)

    function SpawnZombieWave()
        for _, coord in ipairs(Config.ZombieCoords) do
            if not isRobberyActive then break end  
            local zombieModel = Config.ZombieModels[math.random(#Config.ZombieModels)]
            RequestModel(zombieModel)
            while not HasModelLoaded(zombieModel) do
                Citizen.Wait(500)
            end
            local zombie = CreatePed(4, GetHashKey(zombieModel), coord.x, coord.y, coord.z, 0.0, true, true)
            SetEntityHealth(zombie, Config.ZombieHealth)
            SetEntityAsMissionEntity(zombie, true, true)
            SetPedCombatAttributes(zombie, 46, true)
            SetPedFleeAttributes(zombie, 0, 0)
            SetPedCombatAbility(zombie, 2)
            SetPedCombatRange(zombie, 2)
            SetPedCombatMovement(zombie, 3)
            SetPedSeeingRange(zombie, 100.0)
            SetPedHearingRange(zombie, 100.0)
            SetPedAlertness(zombie, 3)
            local playerPed = GetPlayerPed(-1)
            TaskCombatPed(zombie, playerPed, 0, 16)
            Citizen.CreateThread(function()
                while isRobberyActive do
                    Citizen.Wait(2000)
                    if IsPedDeadOrDying(zombie) then
                        DeleteEntity(zombie)
                        break
                    end
                    local zombieCoords = GetEntityCoords(zombie)
                    local playerCoords = GetEntityCoords(playerPed)
                    local distance = #(playerCoords - zombieCoords)
                    if distance > 5.0 then
                        TaskGoToEntity(zombie, playerPed, -1, 0.0, 1.0, 1073741824, 0)
                    end
                end
            end)

            table.insert(spawnedZombies, zombie)
        end
    end
    Citizen.CreateThread(function()
        local robberyStarted = false  
        local lastRobberyTime = 0  
        while true do
            Citizen.Wait(0)
            local playerCoords = GetEntityCoords(PlayerPedId())
            local startDistance = #(playerCoords - Config.StartCP)
            if startDistance < 42.0 then
                DrawMarker(42, Config.StartCP.x, Config.StartCP.y, Config.StartCP.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 255, 0, 0, 100, false, true, 2, false, nil, nil, false)
             if startDistance < 2.0 and not robberyStarted then
                    local currentTime = GetGameTimer()
                    local remainingTime = Config.RobberyCooldown - math.floor((currentTime - lastRobberyTime) / 1000)
                    if remainingTime > 0 then
                        DrawText3D(Config.StartCP.x, Config.StartCP.y, Config.StartCP.z, "Még " .. remainingTime .. " másodpercet kell várnod a rablás indításához.")
                    else
                        DrawText3D(Config.StartCP.x, Config.StartCP.y, Config.StartCP.z, "Nyomj [E] gombot a rablás indításához!")
                        if IsControlJustReleased(0, 38) then -- 38 = E gomb
                            TriggerServerEvent('checkPoliceAndStartRobbery')
                            robberyStarted = true  
                            lastRobberyTime = currentTime  
                        end
                    end
                end
            end
            if isRobberyActive then
                for index, lootCP in ipairs(Config.LootCPs) do
                    local lootDistance = #(playerCoords - lootCP)
                    if lootDistance < 43.0 then
                        DrawMarker(35, lootCP.x, lootCP.y, lootCP.z, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 255, 255, 0, 100, false, true, 2, false, nil, nil, false)
                        if lootDistance < 2.0 and not lootedCPs[index] then  
                            DrawText3D(lootCP.x, lootCP.y, lootCP.z, "Nyomj [E] gombot a lootoláshoz!")
                            if IsControlJustReleased(0, 38) then
                                TriggerServerEvent('lootCP', index)
                                lootedCPs[index] = true  
                                Citizen.Wait(500)  
                            end
                        end
                    end
                end
            end
        end
    end)
    function DrawText3D(x, y, z, text)
        local onScreen, _x, _y = World3dToScreen2d(x, y, z)
        if onScreen then
            SetTextScale(0.35, 0.35)
            SetTextFont(4)
            SetTextProportional(1)
            SetTextColour(255, 255, 255, 215)
            SetTextEntry("STRING")
            SetTextCentre(1)
            AddTextComponentString(text)
            DrawText(_x, _y)
        end
    end
    RegisterNetEvent('giveReward')
    AddEventHandler('giveReward', function(cpIndex, amount)
        if not amount then
            amount = 0
        end
        if lootedCPs[cpIndex] then
            sendNotification("Hiba", "Ezt a CP-t már lootoltad!", 3000, 'error')
            return
        end
        lootedCPs[cpIndex] = true
        RemoveBlip(cpIndex)
        TriggerServerEvent('removeCheckpointServer', cpIndex)
        currentLootIndex = currentLootIndex + 1
        if currentLootIndex >= #Config.LootCPs then
            sendNotification("Rablás vége", "Összes loot megszerezve, Menekülj!", 5000, 'error')
        end
    end)
    function SpawnZombieWave()
        for _, coord in ipairs(Config.ZombieCoords) do
            if not isRobberyActive then break end  

            local zombieModel = Config.ZombieModels[math.random(#Config.ZombieModels)]
            RequestModel(zombieModel)

            while not HasModelLoaded(zombieModel) do
                Citizen.Wait(500)
            end
            local zombie = CreatePed(4, GetHashKey(zombieModel), coord.x, coord.y, coord.z, 0.0, true, true)
            SetEntityHealth(zombie, Config.ZombieHealth)
            SetEntityAsMissionEntity(zombie, true, true)
            SetPedCombatAttributes(zombie, 46, true)
            SetPedFleeAttributes(zombie, 0, 0)
            SetPedCombatAbility(zombie, 2)
            SetPedCombatRange(zombie, 2)
            SetPedCombatMovement(zombie, 3)
            SetPedSeeingRange(zombie, 100.0)
            SetPedHearingRange(zombie, 100.0)
            SetPedAlertness(zombie, 3)
            local playerPed = GetPlayerPed(-1)
            TaskCombatPed(zombie, playerPed, 0, 16)
            Citizen.CreateThread(function()
                while isRobberyActive do
                    Citizen.Wait(2000)
                    if IsPedDeadOrDying(zombie) then
                        DeleteEntity(zombie)
                        break
                    end
                    local zombieCoords = GetEntityCoords(zombie)
                    local playerCoords = GetEntityCoords(playerPed)
                    local distance = #(playerCoords - zombieCoords)
                    if distance < 10.0 then
                        TaskCombatPed(zombie, playerPed, 0, 16)
                    elseif distance > 5.0 then
                        TaskGoToEntity(zombie, playerPed, -1, 0.0, 1.0, 1073741824, 0)
                    end
                end
            end)
            table.insert(spawnedZombies, zombie)
        end
    end
    function StartZombieWaves()
        Citizen.CreateThread(function()
            while isRobberyActive do
                SpawnZombieWave()
                Citizen.Wait(Config.ZombieRespawnTime * 1000)
            end
        end)
    end
    function RemoveCheckpoint(cpIndex)
        if DoesBlipExist(blips[cpIndex]) then
            RemoveBlip(blips[cpIndex])  
        end
        blips[cpIndex] = nil  
    end
    function CheckLootedCPs()
        local currentTime = GetGameTimer() / 1000  
        for cpIndex, lootTime in pairs(lootedCPs) do
            if currentTime - lootTime > Config.LootTimeout then
                RemoveCheckpoint(cpIndex)  
                lootedCPs[cpIndex] = nil  
            end
        end
    end
    RegisterNetEvent('updateLootedCPs')
    AddEventHandler('updateLootedCPs', function(updatedLootedCPs)
        lootedCPs = updatedLootedCPs
        for cpIndex, lootTime in pairs(lootedCPs) do
            RemoveCheckpoint(cpIndex)  
        end
    end)
    local isRobbing = false
    local lastRobberyTime = 0
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
            local playerCoords = GetEntityCoords(PlayerPedId())
            local startDistance = #(playerCoords - Config.StartCP)
            if startDistance < 2.0 then
                DrawText3D(Config.StartCP.x, Config.StartCP.y, Config.StartCP.z, "Nyomj [E] gombot a rablás indításához!")
                if IsControlJustReleased(0, 38) then  
                    TriggerServerEvent('checkPoliceAndStartRobbery')
                end
            end
        end
    end)
    RegisterNetEvent('sendNotification')
    AddEventHandler('sendNotification', function(title, message)
        local duration = Config.NotificationDuration
        local type = Config.NotificationType
        if Config.NotificationSystem == 'okokNotify' then
            TriggerEvent('okokNotify:Alert', title, message, duration, type)
        elseif Config.NotificationSystem == 'esx:showNotification' then
            ESX.ShowNotification(message)
        elseif Config.NotificationSystem == 'pNotify' then
            TriggerEvent('pNotify:SendNotification', {
                text = message,
                type = type,
                timeout = duration
            })
        elseif Config.NotificationSystem == 'mythic_notify' then
            TriggerEvent('mythic_notify:SendAlert', {
                type = type,
                text = message,
                length = duration
            })
        end
    end)
    local isAnimPlaying = false
    function PlayLootAnimation()
        local playerPed = PlayerPedId()

        RequestAnimDict("amb@prop_human_bum_bin@base")
        while not HasAnimDictLoaded("amb@prop_human_bum_bin@base") do
            Citizen.Wait(100)
        end
        FreezeEntityPosition(playerPed, true)
        TaskPlayAnim(playerPed, "amb@prop_human_bum_bin@base", "base", 8.0, -8.0, -1, 1, 0, false, false, false)
        isAnimPlaying = true
        Citizen.Wait(5000)
        StopAnimTask(playerPed, "amb@prop_human_bum_bin@base", "base", 1.0)
        FreezeEntityPosition(playerPed, false)
        isAnimPlaying = false
    end
    RegisterNetEvent('startLootAnimation')
    AddEventHandler('startLootAnimation', function()
        if not isAnimPlaying then
            PlayLootAnimation()
        end
    end)

