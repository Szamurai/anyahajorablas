Config = {

    StartCP = vector3(3091.48, -4723.66, 27.29), -- Kezdő checkpoint (itt indítod a rablást)
    RobberyCooldown = 30, -- 10 másodperc (csak teszteléshez, 300 másodperc = 5 perc)

    -- Időzítők
    LootTime = 10000, -- Másodperc, amíg a rablás tart
    NotifyTime = 5, -- Másodperc, amíg az értesítés látható

    -- Jutalom
    RewardPerCP = 10000, -- Jutalom lootolásonként (black money)
    TotalReward = 0, -- ha ezt választod akkor összes ládát elosztja és azt a pénzt kapod meg pl egészre jelenleg 10000-et.

    -- Discord webhook
    WebhookURL = "", -- Discord webhook URL

    -- Frakciók
    Factions = {
        "police",
        "swat",
        "fbi",
        "sheriff"
    },

    -- Loot checkpointok
    LootCPs = {
        vector3(3066.55, -4773.80, 6.08),
        vector3(3092.37, -4796.28, 6.08),
        vector3(3068.23, -4752.58, 6.08), 
        vector3(3073.94, -4729.19, 6.08),
        vector3(3034.15, -4683.00, 6.08),
        vector3(3068.08, -4658.67, 6.08),
        vector3(3033.54, -4638.40, 6.08),
        vector3(3065.17, -4641.30, 6.08),
        vector3(3038.59, -4659.63, 6.08),
    },

    -- Értesítési üzenet
    NotifyMessage = "Az anyahajó Rablás elindult! Kérjük, reagáljon az eseményre!",

    -- Minimális rendőr szám (ehhez szükséges)
    MinPoliceRequired = 1, -- Legalább 0 rendőr kell (állítsd a kívánt értékre, például 1 vagy 2)

    -- Zombik beállításai
    ZombieCoords = {
        vector3(3066.55, -4773.80, 6.08),
        vector3(3092.37, -4796.28, 6.08),
        vector3(3068.23, -4752.58, 6.08),
        vector3(3073.94, -4729.19, 6.08),
        vector3(3034.15, -4683.00, 6.08),
        vector3(3068.08, -4658.67, 6.08),
        vector3(3033.54, -4638.40, 6.08),
        vector3(3065.17, -4641.30, 6.08),
    },

    -- Zombi modellek egy listában
    ZombieModels = { "a_m_m_eastsa_02", "a_m_m_og_boss_01", "s_m_y_prisoner_01" },  -- Több zombi modell
    ZombieHealth = 100,  -- Zombi életereje
    ZombieDamage = 10,   -- Zombi sebzése
    ZombieRespawnTime = 60,  -- Másodperc (hányszor spawnoljanak újra)

    -- Értesítési rendszer beállításai
    NotificationSystem = 'pNotify',  -- Lehet 'okokNotify', 'esx:showNotification', 'pNotify', 'mythic_notify', stb.
    NotificationDuration = 5000,  -- Alapértelmezett értesítés időtartama
    NotificationType = 'success',  -- Alapértelmezett értesítés típus (success, error, info, stb.)  
    }

-- Értesítési függvény
function sendNotification(title, message)
    local duration = Config.NotificationDuration
    local type = Config.NotificationType

    if Config.NotificationSystem == 'okokNotify' then
        TriggerEvent('okokNotify:Alert', title, message, duration, type)
    elseif Config.NotificationSystem == 'esx:showNotification' then
        ESX.ShowNotification(message)
    elseif Config.NotificationSystem == 'pNotify' then
        TriggerEvent('pNotify:SendNotification', {
            text = message,
            type = type,
            timeout = duration
        })
    elseif Config.NotificationSystem == 'mythic_notify' then
        TriggerEvent('mythic_notify:SendAlert', {
            type = type,
            text = message,
            length = duration
        })
    end
end