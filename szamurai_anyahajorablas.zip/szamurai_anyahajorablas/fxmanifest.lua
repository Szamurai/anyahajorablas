fx_version 'cerulean'
game 'gta5'

author 'Anyahajo rablas'
description 'Szamurai anyahajó'
version '5.0.0'
lua54 'yes'
shared_scripts {
    'config.lua',
    '@es_extended/imports.lua',
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',  -- Ez hozzáadva
    'server.lua',
}

client_script 'client.lua'

dependency 'es_extended'

escrow_ignore {
    'config.lua',
    'server.lua',
    'client.lua',
}

dependency '/assetpacks'