ESX = exports["es_extended"]:getSharedObject()
local config = Config

-- Változók
local isRobbing = false
local lootedCPs = {}
local currentLootIndex = 1
local robberyCooldown = 0
function notifyFactions(message)
    for _, faction in ipairs(config.Factions) do
        TriggerClientEvent('chat:addMessage', -1, {
            color = { 255, 0, 0 },
            multiline = true,
            args = {"[Rablás]", message}
        })
    end
end
function sendDiscordWebhook(message)
    PerformHttpRequest(config.WebhookURL, function(err, text, headers)
        if err == 200 then
        end
    end, 'POST', json.encode({content = message}), { ['Content-Type'] = 'application/json' })
end
RegisterServerEvent('lootReceived')
AddEventHandler('lootReceived', function(searched)
    TriggerClientEvent('updateLootedCPs', -1, lootedCPs)  
end)
local lootedCPs = {} 
RegisterNetEvent('lootCP')
AddEventHandler('lootCP', function(index)
    local playerId = source
    local lootCP = Config.LootCPs[index]
    if lootedCPs[index] then
        TriggerClientEvent('sendNotification', playerId, "Hiba", "Ez a loot már el lett véve!", 5000, 'error')
        return
    end
    TriggerClientEvent('startLootAnimation', playerId)
    local lootAmount = Config.TotalReward > 0 and math.floor(Config.TotalReward / #Config.LootCPs) or Config.RewardPerCP
    local xPlayer = ESX.GetPlayerFromId(playerId)
    xPlayer.addAccountMoney('black_money', lootAmount)
    lootedCPs[index] = true
    TriggerClientEvent('sendNotification', playerId, "Sikeres Lootolás", "Sikeresen kifosztottál egy helyet! Nyertél: " .. lootAmount .. " fekete pénz.", 5000, 'success')
    TriggerClientEvent('updateLootedCPs', -1, lootedCPs)
    if #lootedCPs >= #Config.LootCPs then
        TriggerClientEvent('sendNotification', playerId, "Rablás vége", "Összes lootot megszerezted! Menekülj!", 5000, 'error')
        TriggerClientEvent('stopRobberyClient', playerId)
    end
    local lootMessage = "Rablás során lootolva! Játékos: " .. xPlayer.getName() .. " (" .. xPlayer.identifier .. ") - Loot: " .. lootAmount .. " black money"
    sendDiscordWebhook(lootMessage)
end)
function sendNotification(title, message, duration, type)
    if Config.NotificationSystem == 'okokNotify' then
        TriggerEvent('okokNotify:Alert', title, message, duration, type)
    elseif Config.NotificationSystem == 'esx:showNotification' then
        ESX.ShowNotification(message)
    elseif Config.NotificationSystem == 'pNotify' then
        TriggerEvent('pNotify:SendNotification', {
            text = message,
            type = type,
            timeout = duration
        })
    elseif Config.NotificationSystem == 'mythic_notify' then
        TriggerEvent('mythic_notify:SendAlert', {
            type = type,
            text = message,
            length = duration
        })
    end
end
local lastRobberyTime = 0  
RegisterServerEvent('checkPoliceAndStartRobbery')
AddEventHandler('checkPoliceAndStartRobbery', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local policeCount = 0
    for _, playerId in ipairs(ESX.GetPlayers()) do
        local player = ESX.GetPlayerFromId(playerId)
        for _, faction in ipairs(Config.Factions) do
            if player.job.name == faction then
                policeCount = policeCount + 1
                break
            end
        end
    end
    if policeCount < Config.MinPoliceRequired then
        TriggerClientEvent('sendNotification', source, "Hiba", "Nincs elég rendőr online! Szükséges: " .. Config.MinPoliceRequired)
        local message = "Rablás próbálkozás! Nincs elég rendőr online! Játékos: " .. xPlayer.getName() .. " (" .. xPlayer.identifier .. ") - Online rendőrök: " .. policeCount .. " - Szükséges: " .. Config.MinPoliceRequired
        sendDiscordWebhook(message)

        return
    end
    TriggerClientEvent('startRobberyClient', source)
    local message = "Rablás elindítva! Játékos: " .. xPlayer.getName() .. " (" .. xPlayer.identifier .. ") - Online rendőrök: " .. policeCount
    sendDiscordWebhook(message)
end)
RegisterNetEvent('startRobberyServer')
AddEventHandler('startRobberyServer', function()
    TriggerClientEvent('sendNotification', -1, "Rablás Indítva", "Az anyahajó rablás elkezdődött, a kalózkodás engedélyezett!", 5000, 'success')
end)
RegisterNetEvent('startLootTimer')
AddEventHandler('startLootTimer', function(index)
    local playerPed = PlayerPedId()
    local lootCP = Config.LootCPs[index]
    local timer = Config.LootTime / 1000  
    PlayLootAnimation()
    while timer > 0 do
        Citizen.Wait(1000)  
        timer = timer - 1
        DrawText3D(lootCP.x, lootCP.y, lootCP.z, "Lootolás: " .. timer .. " másodperc")
    end
    TriggerServerEvent('lootCPFinished', index)
    local lootMessage = "Lootolás befejezve! Játékos: " .. xPlayer.getName() .. " (" .. xPlayer.identifier .. ") - Helyszín: " .. tostring(lootCP) .. " - Loot idő: " .. os.date("%Y-%m-%d %H:%M:%S")
    sendDiscordWebhook(lootMessage)
end)
RegisterServerEvent('lootCPFinished')
AddEventHandler('lootCPFinished', function(index)
    local xPlayer = ESX.GetPlayerFromId(source)
    if lootedCPs[index] then
        TriggerClientEvent('sendNotification', source, "Hiba", "Ez a loot már el lett véve!", 5000, 'error')
        return
    end
    local lootAmount = config.TotalReward > 0 and math.floor(config.TotalReward / #Config.LootCPs) or config.RewardPerCP
    xPlayer.addAccountMoney('black_money', lootAmount)
    lootedCPs[index] = true
    TriggerClientEvent('updateLootedCPs', -1, lootedCPs)
    if #lootedCPs >= #Config.LootCPs then
        TriggerClientEvent('stopRobberyClient', source)
    end
    local lootMessage = "Rablás során lootolva! Játékos: " .. xPlayer.getName() .. " (" .. xPlayer.identifier .. ") - Loot: " .. lootAmount .. " black money"
    sendDiscordWebhook(lootMessage)
end)

